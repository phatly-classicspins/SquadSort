# Mockup asset pack

Status: **2D source art + 3D references awaiting approval. No FBX/GLB or rig is delivered yet.**

## Available files

- `textures/courtyard-background.png`: clean background plate.
- `ui/ui-atlas.png`: eight controls on real alpha transparency.
- `ui/sprite-rects.json`: eight pixel slice windows, including Unity bottom-left coordinates. The last row is intentionally not a uniform two-column slice.
- `models/character-purple/blueprint.png`: four-view character form reference.
- `models/queue-four/blueprint.png`: open-entry 3D queue reference.
- `models/waiting-board/blueprint.png`: stepped waiting tray reference.
- `design-tokens.json`: ten planned character variants, materials, dimensions and mesh contract.
- `prompts.json`: exact generation prompts and mode.
- `reference/mockup.png`: source style reference.

These are newly generated assets derived from the mockup, not pixels extracted from the original game.

## Real 3D scope

Characters and both container types must be real meshes, not baked character/board sprites. The shared body has independent eyes, mouth, arms, feet and accessory parts. Ten planned variants: purple, blue, green, orange, yellow, red, pink, brown, cyan and masked gray. FBX convention: metres, Y up, +Z front, bottom-centre pivot. Sleeping/awake face states and animation are future mesh/rig work, not present in these images.

The waiting tray is modular: floor cells and edge/corner pieces follow occupancy, with no wall blocking a queue port. Its blueprint illustrates one seven-cell layout. Do not bake that single layout into every level.

## Review and limitations

The image sheets are visual references, not dimension-verified CAD. Some queue elevations retain perspective. Request dimensions govern modelling. Model-gen silhouette, triangle, pivot and export checks have not been run. Blender was not found in the inspected standard locations/PATH; prepare a Blender runtime before model build.

The project skill `.claude/skills/pf-model-gen/SKILL.md` explicitly requires approval of the blueprint before `build`. All blueprint provenance remains `pending-user-review`; do not treat the generated images as completed models.

No Unity assets, scenes, prefabs or game code changed by this handoff.

Skipped: Unity import and visual integration.
Skipped: Unity EditMode / PlayMode suites and batchmode.
Skipped: engine-free game gate (art-only package; no gameplay/source change).
